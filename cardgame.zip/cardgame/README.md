# cardgame

Cardgame is a skill that demonstrates multi-party interaction (one or two players are currently supported) and the use of a GUI. 
It is supposed to be played with a touchscreen (an ipad work fine) placed on the table in front of Furhat. 

Currently, only English is supported. More languages can be added under furhatos.app.cardgame.locales. We suggest to copy the English locale as a basis. The locale is set in main.kt. 

Each locale also ha a set of decks, found under the decks folder in the locale. These can easily be extended. 

# Citation .bib
@misc{skantze_gabriel_cardgame_2022,
	title = {{CardGame}},
	url = {https://github.com/FurhatRobotics/prototype-skills/tree/main/cardgame},
	abstract = {Multi-party mutlti-modal interaaction (Skill) created for the Furhat Robot Platform.},
	publisher = {Furhat Robotics},
	author = {{Skantze, Gabriel}},
	year = {2022},
}
